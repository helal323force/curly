const fs = require("fs");  
const path = require("path");  
const axios = require("axios");  
const Photo360 = require("abir-photo360-apis");  

module.exports = {  
  config: {  
    name: "ep",  
    version: "1.2.0",  
    permission: 0,  
    credits: "Helal",  
    description: "Generate stylish images using Ephoto360 templates",  
    category: "textmaker",  
    usages: "/ephoto <template> <name>",  
    cooldowns: 5  
  },  

  onStart: async function({ api, event, args }) {

    // 🔐 ADMIN-ONLY LOCK (Main + 2 Optional)
    const allowedUsers = [
      "61586475611589", // Main Admin: Helal
      "61585520407950", // Optional Admin Slot 1
      "Uid3"  // Optional Admin Slot 2
    ];

    if (!allowedUsers.includes(event.senderID)) {
      return api.sendMessage(
        "❌ You are not authorized to use this command.",
        event.threadID,
        event.messageID
      );
    }
    // 🔐 END ADMIN CHECK

    if (!args[0] || !args[1]) {  
      return api.sendMessage(  
        "❌ Please provide a template ID and a name.\n\nExample:\n/ephoto 52 Helal",  
        event.threadID,  
        event.messageID  
      );  
    }  

    const templateKey = args[0].toLowerCase();  
    const name = args.slice(1).join(" ") || "Helal";  
    const cacheDir = path.join(__dirname, "cache");  
    const imagePath = path.join(cacheDir, "ephoto_output.png");  

    const templates = {  
      "1":"https://en.ephoto360.com/handwritten-text-on-foggy-glass-online-680.html",  
      "2":"https://en.ephoto360.com/create-realistic-cloud-text-effect-606.html",  
      "3":"https://en.ephoto360.com/light-glow-text-effect-369.html",  
      "4":"https://en.ephoto360.com/glitch-text-effect-online-345.html",  
      "5":"https://en.ephoto360.com/3d-metal-text-effect-600.html",  
      "6":"https://en.ephoto360.com/foggy-rainy-text-effect-75.html",  
      "7":"https://en.ephoto360.com/write-in-sand-summer-beach-online-free-595.html",  
      "8":"https://en.ephoto360.com/diamond-text-95.html",  
      "9":"https://en.ephoto360.com/create-multicolored-neon-light-signatures-591.html",  
      "10":"https://en.ephoto360.com/create-broken-glass-text-effect-online-698.html",  
      "11":"https://en.ephoto360.com/create-multicolored-signature-attachment-arrow-effect-714.html",  
      "12":"https://en.ephoto360.com/create-a-graffiti-text-effect-on-the-wall-online-665.html",  
      "13":"https://en.ephoto360.com/create-a-watercolor-text-effect-online-655.html",  
      "14":"https://en.ephoto360.com/creating-text-effects-night-lend-for-word-effect-147.htm",  
      "15":"https://en.ephoto360.com/write-text-effect-clouds-in-the-sky-online-619.html",  
      "16":"https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html",  
      "17":"https://en.ephoto360.com/dark-green-typography-online-359.html",  
      "18":"https://en.ephoto360.com/stars-night-online-1-85.html",  
      "19":"https://en.ephoto360.com/realistic-3d-sand-text-effect-online-580.html",  
      "20":"https://en.ephoto360.com/create-a-summery-sand-writing-text-effect-577.html",  
      "21":"https://en.ephoto360.com/text-firework-effect-356.html",  
      "22":"https://en.ephoto360.com/ligatures-effects-from-leaves-146.html",  
      "23":"https://en.ephoto360.com/write-letters-on-the-leaves-248.html",  
      "24":"https://en.ephoto360.com/graffiti-color-199.html",  
      "25":"https://en.ephoto360.com/caper-cut-effect-184.html",  
      "26":"https://en.ephoto360.com/dragon-fire-text-effect-111.html",  
      "27":"https://en.ephoto360.com/ice-text-effect-online-101.html",  
      "28":"https://en.ephoto360.com/purple-text-effect-online-100.html",  
      "29":"https://en.ephoto360.com/text-effects-incandescent-bulbs-219.html",  
      "30":"https://en.ephoto360.com/text-heart-flashlight-188.html",  
      "31":"https://en.ephoto360.com/metal-text-effect-blue-174.html",  
      "32":"https://en.ephoto360.com/text-light-effets-234.html",  
      "33":"https://en.ephoto360.com/vibrant-fireworks-text-effect-535.html",  
      "34":"https://en.ephoto360.com/text-logo-maker-online-free-474.html",  
      "35":"https://en.ephoto360.com/write-texts-on-beautiful-christmas-ball-ornaments-501.html",  
      "36":"https://en.ephoto360.com/create-eraser-deleting-text-effect-online-717.html",  
      "37":"https://en.ephoto360.com/boom-text-comic-style-text-effect-675.html",  
      "38":"https://en.ephoto360.com/light-text-effect-futuristic-technology-style-648.html",  
      "39":"https://en.ephoto360.com/christmas-and-new-year-glittering-3d-golden-text-effect-794.html",  
      "40":"https://en.ephoto360.com/create-a-beautiful-3d-christmas-snow-text-effect-793.html",  
      "42":"https://en.ephoto360.com/create-sparkles-3d-christmas-text-effect-online-727.html",  
      "43":"https://en.ephoto360.com/create-dragon-ball-style-text-effects-online-809.html",  
      "44":"https://en.ephoto360.com/create-online-3d-comic-style-text-effects-817.html",  
      "45":"https://en.ephoto360.com/green-brush-text-effect-typography-maker-online-153.html",  
      "46":"https://en.ephoto360.com/creating-text-effects-night-lend-for-word-effect-147.html",  
      "47":"https://en.ephoto360.com/galaxy-text-effect-116.html",  
      "48":"https://en.ephoto360.com/dragon-fire-text-effect-111.html",  
      "49":"https://en.ephoto360.com/paint-splatter-text-effect-72.html",  
      "50":"https://en.ephoto360.com/halloween-fire-text-online-83.html",  
      "51":"https://en.ephoto360.com/writing-horror-text-online-266.html",  
      "52":"https://en.ephoto360.com/naruto-shippuden-logo-style-text-effect-online-808.html",  
      "53":"https://en.ephoto360.com/halloween-fire-text-effect-online-369.html",  
      "54":"https://en.ephoto360.com/write-your-name-on-horror-cemetery-gate-597.html",  
      "55":"https://en.ephoto360.com/neon-devil-wings-text-effect-online-683.html"  
    };  

    const templateUrl = templates[templateKey];  
    if (!templateUrl) {  
      const available = Object.keys(templates).join(", ");  
      return api.sendMessage(  
        `❌ Invalid template selected!\nAvailable templates:\n${available}\n\nExample:\n/ephoto 52 Helal`,  
        event.threadID,  
        event.messageID  
      );  
    }  

    if (!fs.existsSync(cacheDir)) fs.mkdirSync(cacheDir, { recursive: true });  

    try {  
      const photo360 = new Photo360(templateUrl);  
      photo360.setName(name);  
      const result = await photo360.execute();  

      const response = await axios.get(result.imageUrl, { responseType: "arraybuffer" });  
      fs.writeFileSync(imagePath, response.data);  

      return api.sendMessage(  
        {  
          body: `✅ Image generated for "${name}" using template #${templateKey}`,  
          attachment: fs.createReadStream(imagePath)  
        },  
        event.threadID,  
        event.messageID  
      );  
    } catch (err) {  
      console.error("Ephoto Error:", err.message);  
      return api.sendMessage(  
        "❌ Something went wrong while generating the image. Please try again later.",  
        event.threadID,  
        event.messageID  
      );  
    }  
  }  
};
